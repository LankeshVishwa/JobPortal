function chkclick(){
	var itg=document.getElementById('chge');
	if(itg.style.display=='none' ){
		itg.style.display='block';
	}
	else
		itg.style.display='none';
}
function empclick(){
	var itg=document.getElementById('empchk');
	if(itg.style.display=='none' ){
		itg.style.display='block';
	}
	else
		itg.style.display='none';
}