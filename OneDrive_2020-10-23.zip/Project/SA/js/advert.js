function checkid()
{	
	var response;
	if(document.getElementById("emp").value !=document.getElementById("re_emp").value)
	{
		alert("Employee ID is mismatch!!");
		return false;
	}
	else{
		alert("Employee ID is matched !!");
		
		return response=confirm("Do you want to submit ?");
	}
	
}
function checkprofile(){
	if(confirm("Do you want to log out!!")==true)
	{
		return change=window.location.replace("../../OJB_Homepage.html");
	}
	else{
		return change=window.location.replace("index.html");
	}
	
	
}

function checkclick(){
	return change=window.location.href="blank.html";
	
}
function update(){

	document.getElementById("change1").innerHTML=document.getElementById("change").innerHTML;
}
function reset(){
	return change=window.location.replace("advert.html");
	
}

