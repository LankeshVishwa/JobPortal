<!DOCTYPE html>
<?php
	include 'config.php';	
?>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Advertisement</title>
	<link rel="stylesheet" href="../css/ad.css">
	<script src="../js/advert.js"></script>
  </head>
  <body class="back">
  <div class="adjust">
  <div class="backimg"> </div>
<div class="polygon3">
      <div class="logo">
        <img class="img" src="../images/logo.png" alt="logo image">
      </div>

      

<br><br><br><br><br><br><br><br><br><br><br><br>

	<?php
	include 'config.php';

	
	$Id= $_GET['id'];
	$sql = "SELECT * FROM delete_table where Ad_ID='$Id'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$mem_ID=$row['Ad_ID'];
			$name=$row['Ad_title'];
			$duration=$row['duration'];
			$emp_id=$row['Emp_id'];
			$message=$row['Image'];
			
		
			}
	}
	?>
	<center>
	<table><tr><th>Advertisement Title</th>&nbsp<th>Ad ID</th>&nbsp <th>Duration</th> &nbsp <th>Employer ID</th></tr><tr>
	<td><?php echo $name;?></td>&nbsp<td><?php echo $mem_ID;?></td>&nbsp<td><?php echo $duration;?></td>&nbsp<td><textarea><?php echo $emp_id;?></textarea></td></tr></table>
	</center>
	
	<?php
	echo "<br>";
	echo "<center><a href='Overview.php'>BACK</a></center>";
		
	?>
	
	<br><br><br><br><br>
	

	
	<center>
	</div>
	</div>
	
	<hr class= "height">
	<div class="height">
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
	</footer>
 </div>
  </body>

</html>










