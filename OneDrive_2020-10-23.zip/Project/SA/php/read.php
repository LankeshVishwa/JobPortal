<!DOCTYPE html>
<?php
	include 'config.php';	
?>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Advertisement</title>
	<link rel="stylesheet" href="../css/ad.css">
	<script src="../js/advert.js"></script>
  </head>
  <body class="back">
  <div class="adjust">
  <div class="backimg"> </div>
<div class="polygon3">
      <div class="logo">
        <img class="img" src="../images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="../html/index.html">Home</a></li>
          <li><a href="advert.php">Advertisement</a></li>
          <li><a href="../html/feedback.html">Feedback</a></li>
		  <li><a href="../html/Overview.html">Overview</a></li>
		  
        </ul>
      </header>

<br><br><br><br><br><br><br><br><br><br><br><br>
	<?php
	include 'config.php';

	
	$Id= $_GET['id'];
	$sql = "SELECT * FROM advert where Ad_ID='$Id'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc())
			{
			$id=$row["Ad_ID"];
			$title = $row["Ad_title"];
			$Period = $row["duration"];
			$employer = $row["Emp_id"];
			$image=$row["Image"];
			
		
			}
	}
	?>
	<center>
	<form action="mod.php" method="POST" >
		<label>Advertisement Title</label>
		<input type="text" name="title" value= <?php echo $title ?> /><br>

		<label>Employer ID</label>
		<input type="text" name="emp_id" value= <?php echo $employer ?> /><br>
		
		<label>Duration</label>
		<input type="text" name="duration" value= <?php echo $Period ?> /><br>
		
		<label>Advertisement ID</label>
		<input type="text" name="ad_ID"  value= <?php echo $id ?> /><br>
		
		
		<input type="Submit" value="Update" >

	</form>
	<center>
<?php
	echo "<br>";
	echo "<center><a href='delete.php?id=".$id."'>DELETE</a></center>";
	echo "<center><a href='advertisement.php'>BACK</a></center>";
		
	?>
	<br><br><br><br><br>
	

	
	<center>
	</div>
	</div>
	
	<hr class= "height">
	<div class="height">
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
	</footer>
 </div>
  </body>

</html>










