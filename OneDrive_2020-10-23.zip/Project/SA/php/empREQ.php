<?php

	include 'config.php';
	
	$mem_ID=$_POST['memID'];
	$name=$_POST['memName'];
	$company=$_POST['coName'];
	$email_ID=$_POST['emailid'];
	$message=$_POST['msg'];
	
	$sql="INSERT INTO e_requests(Emp_ID,Employer_Name,Com_Name,Email_ID,Msg)
	
	VALUES('$mem_ID','$name','$company','$email_ID','$message')";
	
	if($conn -> query($sql))
	{
		header("Location:../html/feedback.html");	
	}
	else{
		echo"Error inserting".$conn->error;
	}
	$conn -> close();
	
	



?>