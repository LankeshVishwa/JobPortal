<?php
   include 'config.php';

	$id = $_POST["ad_ID"];
	$title = $_POST["title"];
	$employer_id = $_POST["emp_id"];
	$duration = $_POST["duration"];
	$image = $_POST["Upimage"];
	 

	
	$sql = "UPDATE advert SET Ad_title='$title',duration='$duration',Emp_id='$employer_id', Image='$image' WHERE Ad_ID='$id'";
	
	if($conn -> query($sql)){
		
		header("Location:advertisement.php");
	} 
	else{
		echo "<script> alert(' ERROR: Could not able to execute $sql. ')</script>" ;
	}
	 
	// Close connection
	mysqli_close($conn);

?>