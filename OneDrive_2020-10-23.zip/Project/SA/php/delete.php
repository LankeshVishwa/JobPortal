<?php
    include 'config.php';

	$Id = $_GET['id'];
	
	GLOBAL $ad_id;
	GLOBAL $title;
	GLOBAL $duration;
	GLOBAL $employerID;
	GLOBAL $image;
	
	
	$sql1 = "SELECT * FROM advert where Ad_ID='$Id'";
	$result = $conn->query($sql1);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$ad_id=$row['Ad_ID'];
			$title = $row['Ad_title'];
			$duration = $row['duration'];
			$employerID = $row['Emp_id'];
			$image=$row['Image'];
			
		
			}
	}

	$sql2="INSERT INTO delete_table(Ad_ID,Ad_title,duration,Emp_id,Image)
	VALUES('$ad_id','$title','$duration','$employerID','$image')";
	if($conn->query($sql2))
	{
		echo"<script>alert('Succesfully Moved')</script>";
	}
	else{
		echo"Error inserting".$conn->error;
	}
	
	$sql = "DELETE FROM advert WHERE Ad_ID='$Id'";
	
	if($conn -> query($sql)){
		echo "<script> alert('Advertisement record deleted successfully!')</script>";
		header("Location:advertisement.php");
	} 
	else{
		echo "<script> alert('ERROR: Could not able to execute $sql. ')</script>" ;
	}
	 
	//Close connection
	mysqli_close($conn);

?>