

<!DOCTYPE html>
<?php
	include 'config.php';	
?>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Advertisement</title>
	<link rel="stylesheet" href="../css/ad.css">
	<script src="../js/advert.js"></script>
  </head>
  <body class="back">
  <div class="adjust">
  <div class="backimg"> </div>
<div class="polygon3">
      <div class="logo">
        <img class="img" src="../images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="../html/index.html">Home</a></li>
          <li><a href="../php/advertisement.php">Advertisement</a></li>
          <li><a href="../php/feedback.php">Feedback</a></li>
		  <li><a href="../php/Overview.php">Overview</a></li>
		  
        </ul>
      </header>

<br><br><br><br><br><br><br><br><br><br><br><br>
	<div class="dis">
	<center>
	<div class="">
	<table class="border" width=60% >
		<tr>
		<th align="left">Current Advertisements &nbsp &nbsp <br><br><br></th>
		</tr>
		
		<tr>
		<td>
		<ul class="ex1"><center>
		<table class="border"  class="short" border="1%" width=90%>
		<tr>
		
		<th>IT Department</th>
		</tr>
		
		<tr>
		<td>
		<ul>
		
		<!--<li type="none" >Advertisements01 &nbsp &nbsp &nbsp <button type="button" class="mag" id="btn11" onclick="update(btn11)">View</button> &nbsp &nbsp <button type="button" class="mag" id="btn100" onclick="del(btn)">Delete</button></li>
		<li type="none" >Advertisements02 &nbsp &nbsp &nbsp <button type="button" class="mag" id="btn13" onclick="update(btn13)">View</button> &nbsp &nbsp <button class="mag" type="button" id="btn100" onclick="del(btn)">Delete</button></li>
		<li type="none" >Advertisements03 &nbsp &nbsp &nbsp <button type="button" class="mag" id="btn14" onclick="update(btn14)">View</button> &nbsp &nbsp <button class="mag" type="button" id="btn100" onclick="del(btn)">Delete</button></li>
		<li type="none" >Advertisements04 &nbsp &nbsp &nbsp <button type="button" class="mag" id="btn15" onclick="checkclick()">View</button></li>
		<li type="none" >Advertisements05 &nbsp &nbsp &nbsp <button type="button" class="mag" id="btn16" onclick="checkclick()">View</button></li>
		<li type="none" >Advertisements06</li>
		<li type="none" >Advertisements07</li>
		<li type="none" >Advertisements08</li>-->
		<?php
			
			$sql="SELECT * FROM advert";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
					$id=$row['Ad_ID'];
					$title = $row['Ad_title'];
					
					echo "<tr><td>".$title."</td><td><center><a href='read.php?id=".$id."'>view</a><center></td></tr>";
					
					}
					
			}
			?>
		
		
		</ul>
		</td>
		</tr>
		
		</table>
		</center>
		<br><br>
		
		
		</ul>
		</td>
		</tr>
	</table>
	</div>
	</center>
	
	<br><br>
		
	<center>


	
	<table class="border" >
	<tr>
	<th>
	<h2>Add New Advertisement</h2></th>
	</tr>
	<tr>
	<td>
	
	<form action="../php/advert.php" method="POST" target="_self" onsubmit="return checkid()" >
		<label>Advertisement Title</label>
		<input type="text" name="title" required><br><br>
		<label>Advertisement ID</label>
		<input type="text" name="ad_ID"required><br><br>
		
		<label>Duration :</label>&nbsp
		<input type="radio" name="duration" value="1M">&nbsp
		<label>1 Month</label>&nbsp &nbsp
		<input type="radio" name="duration" value="2W">&nbsp
		<label>2 weeks</label><br><br>
		
		<label>Employee ID</label>
		<input type="text" id="emp" name="emp_id" required><br><br>
		
		<label>Re-Enter Employee ID</label>
		<input type="text" id="re_emp" required><br><br>
		
		<input type="file" id="Upimage" name="Upimage" placeholder="Add Image"><br><br>
		<center>
		<input type="submit"  id="btnsubmit" value="ADD"> 
		</center>
		
	</form>
	</td>
	</tr>
	</table>
	</div>



<br><br><br><br>
	<center>
	<div class="short">
	<tr>
	<th align="right"><h1><a href="feedback.html">Employer Requests</a></h1></th>
	</tr>
	</div>
	</center>
	
	<br><br><br><br><br>
	

	
	<center>
	</div>
	</div>
	
	<hr class= "height">
	<div class="height">
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
	</footer>
 </div>
  </body>

</html>