<?php
	include 'config.php';
	$title=$_POST['title'];
	$AD_ID=$_POST['ad_ID'];
	$duration=$_POST['duration'];
	$employerID=$_POST['emp_id'];
	$image=$_POST['Upimage'];
	
	$sql="INSERT INTO advert(Ad_ID,Ad_title,duration,Emp_id,Image)
	
	VALUES('$AD_ID','$title','$duration','$employerID','$image')";
	
	if($conn -> query($sql))
	{
		header("Location:advertisement.php");	
	}
	else{
		echo"Error inserting".$conn->error;
	}
	$conn -> close();

?>