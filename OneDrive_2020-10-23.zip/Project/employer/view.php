<?php

	include 'config.php';
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href = "css/view.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script src ="form.js"></script>
    <meta charset="utf-8">
    <title>Job Requests</title>
  </head>
  <body>
<div class="polygon">
      <div class="logo">
        <img class="img" src="images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="index.html">Home</a></li>
          
          <li><a href="jobpost.html">Post Job</a></li>
          <li><a href="edit.php">Job Posted</a></li>
          <li><a href="view.php">Job Applications</a></li>
        </ul>
        
        
      </header>
<br><br><br><br><br><br><br><br>



<center>


<br><br><br>


<div id = "boxes1">

<center><h2>Requests For your Job vacancy</h2></center>

<br><br><br><br>
<style>
table, td, th {  
  border: 1px solid #000;
  text-align: left;
}

table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 15px;
}
</style>

	<table>
	<table border="1" width = "100%">
	<tr>
		<th>JID</th>
		<th>Employer_ID</th>
		<th>Jname</th>
		<th>Cname</th>
		<th>Cemail</th>
		<th>RID</th>
		<th>Contact</th>
		<th>Ignore</th>
		>
	</tr >
	
<?php
		$sql = "SELECT * FROM apply_job";
		$result = $conn -> query($sql); 
	
		if($result -> num_rows>0)
		{
			while($row = $result -> fetch_assoc())
			{
				$id = $row["JID"];
				$empid = $row["Employer_ID"];
				$name = $row["Jname"];
				$cname = $row["Cname"];
				$email = $row["Cemail"];
				$rid = $row["RID"];
				
				
				echo "<tr>
						<td>".$row["JID"]."</td>
						<td>".$row["Employer_ID"]."</td>
						<td>".$row["Jname"]."</td>
						<td>".$row["Cname"]."</td>
						<td>".$row["Cemail"]."</td>
						<td>".$row["RID"]."</td>
						

						
						<td><button class = 'editbtn' type = 'submit'><a href='resume.php?id=$id'> Contact </a></button></td>
						<td><button class = 'editbtn' type = 'submit'><a href='ignore.php?id=$id'> Ignore </a></button></td>";
			}
		}
		else
		{
			echo "0 Results";
		}
     echo "</table>";
	
	$conn->close();
?>
	
	</table>
	</div>
</center>
		


<div class="agn">
<hr>
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
</footer>
</div>
  </body>
</html>