function myfunction()
{
	alert("Job Added Successfully");
};

function contact()
{
	confirm("Do you want Contact Him ?");
}
function ignore()
{
	confirm("Do you want to ignore the post ?");
}
		
