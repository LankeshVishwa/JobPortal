<?php
    include_once 'config.php';
?>

<?php
	$recordId = $_GET['id'];
	
	$sql = "DELETE FROM employerpost WHERE Employer_ID = '$recordId'";
	
	if($conn -> query($sql)){
		echo "<script> alert('Done!!')</script>";
		header("Location:edit.php");
	} 
	else{
		echo "<script> alert('ERROR: Could not able to execute $sql. ')</script>" ;
	}
	 
	
	mysqli_close($conn);

?>