<?php
    include 'config.php';

	
	$idN = $_POST["id"];
	$name = $_POST["field1"];
	$coname = $_POST["field2"];
	$jcate = $_POST["field3"];
	$quali = $_POST["field4"];
	$location = $_POST["field5"];
	$email = $_POST["field6"];
	$contactno = $_POST["field7"];
	
	

	 
	
	
	$sql ="UPDATE employerpost SET Full_name='$name',Company_Name='$coname',Job_Category='$jcate',Qualifications='$quali',
	Job_Location='$location',Company_Email='$email',Contact_No='$contactno',WHERE Employer_ID='$idN'";
	
	if($conn -> query($sql)){
		echo "<script> alert('successfully!')</script>";
		header("Location:edit.php");
	} 
	else{
		echo "<script> alert(' ERROR: Could not able to execute $sql. ')</script>" ;
	}
	 
	
	mysqli_close($conn);

?>