 <?php
 
	include 'config.php';
 
 
 ?>
 
 
 <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/edit.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Edit</title>
  </head>
  <body>
  
<div class="polygon">
      <div class="logo">
        <img class="img" src="images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="index.html">Home</a></li>
          <li><a href="jobpost.html">Post Job</a></li>
          <li><a href="edit.php">Job Posted</a></li>
          <li><a href="#">About us</a></li>
        </ul>
      
      </header>
<br><br><br><br><br><br><br><br><br>

<?php

		$recordID = $_GET['id'];
		
		$sql = "SELECT*FROM employerpost where Employer_ID = '$recordID'";
		
		$result = $conn -> query($sql);
		
		if($result -> num_rows > 0)
		{
			while($row = $result -> fetch_assoc())
			{
				$id = $row["Employer_ID"];
				$name = $row["Full_name"];
				$coname = $row["Company_Name"];
				$jcate = $row["Job_Category"];
				$quali = $row["Qualifications"];
				$location = $row["Job_Location"];
				$email = $row["Company_Email"];
				$contactno = $row["Contact_No"];
			}
			
		}
		else
		{
			echo "No Results Yet";
		}
?>
<br><br>
<center>
<h2>- Update Your Job Vacancy - </h2>
</center>
<br><br><br><br>
<center>
<table class="form">
	<tr>
	<td>
<div id = "boxes1">

	<form method="POST" action="update.php">
	 
	<label> Job Request ID </label> &nbsp &nbsp &nbsp &nbsp &nbsp 
	<input type="text" name="id" value =<?php echo $id; ?> readonly /> <br><br>
	<label> Full Name </label> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp   
	<input type="text" name = "field1" value =<?php echo $name; ?> /> <br><br>
	<label> Company Name </label> &nbsp &nbsp &nbsp &nbsp 
	<input type="text" name = "field2" value =<?php echo $coname; ?> /> <br><br>
	<label> Job Category </label> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
	<input type="text" name = "field3" value =<?php echo $jcate; ?> /> <br><br>
	<label> Qualifications </label> &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp
	<textarea name="field4"><?php echo $quali; ?></textarea> <br><br>
	<label> Job Location </label> &nbsp &nbsp   &nbsp &nbsp &nbsp &nbsp &nbsp
	<input type="text" name = "field5" value =<?php echo $location; ?> /><br><br>
	<label> Company Email </label> &nbsp &nbsp &nbsp &nbsp &nbsp
	<input type="text" name = "field6" value =<?php echo $email; ?> /><br><br>
	<label> Contact No </label> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
	<input type="text" name = "field7" value =<?php echo $contactno; ?> /><br><br><br><br>
	<input type ="submit" value = "UPDATE">
	
	
	</form>
	
</div>
</td>
	</tr>
	</table>
</center>



<div class="agn">
<hr>
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
	  </div>
     </div>
	
</footer>
  </body>
</html>
