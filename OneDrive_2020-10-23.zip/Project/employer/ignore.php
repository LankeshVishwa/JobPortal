<?php
    include_once 'config.php';
?>

<?php
	$recordId = $_GET['id'];
	
	$sql = "DELETE FROM apply_job WHERE JID = '$recordId'";
	
	if($conn -> query($sql)){
		echo "<script> alert('Done!!')</script>";
		header("Location:view.php");
	} 
	else{
		echo "<script> alert('ERROR')</script>" ;
	}
	 
	
	mysqli_close($conn);

?>