<?php

	include 'config.php';
?>

<?php
	$empid = $_POST["field1"];
	$name = $_POST["field2"];
	$coname =$_POST["field3"] ;
	$category = $_POST["field4"];
	$quali = $_POST["field5"];
	$location = $_POST["field6"];
	$email = $_POST["field7"];
	$contactno = $_POST["field8"];
	
	$sql= "insert into employerpost (Employer_ID,Full_name,Company_Name,Job_Category,Qualifications,Job_Location,Company_Email,Contact_No)
	values('$empid','$name','$coname','$category','$quali','$location','$email','$contactno')";
		
	if($conn-> query($sql))
	{
		echo "<script> alert ('Successfully')</script>";
		header ("Location:Jobpost.html");
	}
	else
	{
		echo "<script>'Something is wrong'</script>";
	}
	
	
	mysqli_close($conn);
?>