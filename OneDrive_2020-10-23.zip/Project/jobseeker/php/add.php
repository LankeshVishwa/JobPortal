


<?php
  include 'config.php';

  $rid=$_POST["title"];
  $name=$_POST["emp_id"];
  $address=$_POST["name"];
  $age=$_POST["email"];
  $dob=$_POST["RID"];


  $sql="insert into apply_job (Employer_ID,Jname,Cname,Cemail,RID)values('$rid','$name','$address','$age','$dob')";

  if(mysqli_query($conn,$sql))
  {
    echo "<script>alert ('Data Input Successfully !!!')</script>";
    header("Location:Job_Apply.php");
  }
  else {
    echo "ERROR INSERTING :- ".$conn->error;
  }
  mysqli_close($conn);
  ?>
