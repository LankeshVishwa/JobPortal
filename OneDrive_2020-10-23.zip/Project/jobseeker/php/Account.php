
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/Account.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Account</title>
  </head>
  <body>
    <div class="polygon">
      <div class="logo">
        <img class="img" src="../images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="Job_Apply.php">Home</a></li>
          <li><a href="Account.php">Job Seeker</a></li>
          <li><a href="Resume.php">Resume Help</a></li>
        </ul>
        <div class="search">

          


          
        </div>
      </header>
		<?php
            include 'config.php';

            GLOBAL $fname;
                  GLOBAL $lname;
                        GLOBAL $email;
                              GLOBAL $dob;
                                    GLOBAL $exp;

              if(isset($_POST['submit']))
              {
                $id=$_POST['id'];
                $sql="SELECT * FROM js where ID='$id' ";

                $result=$conn -> query($sql);

                if($result -> num_rows>0)
                {
                    while($row=$result->fetch_assoc())
                    {
                      $jid=$_POST["id"];
                      $fname=$row['fname'];
                      $lname=$row["lname"];
                      $email=$row["email"];
                      $dob=$row["dob"];
                      $exp=$row["exp"];

                    }
                }
                else {
                  echo "";
                }

              }
              else {
                echo "";
              }
            ?>
      <h3>My Account</h3>
      <div class="genaral">
        <div class="vl"></div>
        <h4>Genaral Information</h4><br><br>
        <form class="" action="" method="post">

          <label for="">ID :- </label>&nbsp
          <input id="Valid"  type="text" name="id" value="">
          <button type="submit" name="submit" class="submit1" value="SUBMIT">Submit</button><br><br><br>
        </form>

        <form class="" action="" method="post">


        <label>First Name :- </label>
        <input type="text" name="" value="<?php echo $fname ?>" ><br><br><br>

        <label>Last Name :- </label>
        <input type="text" name="" value=<?php echo $lname ?>><br><br><br>

        <label>E mail :- </label>
        <input type="text" name="" value=<?php echo $email ?>><br><br><br>

        <label>Date Of Birth :- </label>
        <input  type="text" name="" value=<?php echo $dob ?>><br><br><br>

        <label>Experiance :- </label>
        <input type="text" name="" value=<?php echo $exp ?>><br><br><br><br><br>



        </form>
      </div>



        <img class="background"src="../images/workdesk.jpg" alt="">


      <p class="para">Upload your resume to Jobwind—so that you can apply to jobs with just one click.<br><br>
        *File supported : DOC, DOCX, PDF, RTF, TXT; 5MB Max</p>

      <div class="resume">
      <ul class="list">
        <li><a href="Resume.php">Create Resume</a></li>
        <li><a href="#">Upload Resume</a></li>
      </ul>
      </div>




<hr>

<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">

                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
</footer>
</div>
  </body>
</html>
