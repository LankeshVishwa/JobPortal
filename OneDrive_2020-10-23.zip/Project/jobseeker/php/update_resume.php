<?php
    include_once 'config.php';
?>

<?php
	// Escape user inputs for security
  $rid=$_POST["rid"];
  $name=$_POST["name"];
  $address=$_POST["address"];
  $age=$_POST["age"];
  $dob=$_POST["dob"];
  $status=$_POST["status"];
  $profile=$_POST["Profile"];
  $edu=$_POST["education"];
  $exp=$_POST["experiance"];


	//echo $_GET['id'];
	// Attempt update query execution
  $sql="UPDATE resume SET Name='$name',Address='$address',Age='$age',DOB='$dob',Status='$status',Profile='$profile',Edu='$edu',Exp='$exp' where RID='$rid'";

	if($conn -> query($sql)){
		//echo "<script> alert('Records added successfully!!!!')</script>";
		header("Location:Resume.php");
	}
	else{
		echo "ERROR INSERTING :- ".$conn->error;
	}

	// Close connection
	mysqli_close($conn);

?>
