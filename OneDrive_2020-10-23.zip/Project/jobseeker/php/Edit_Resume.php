<?php
  include 'config.php';
 ?>
    <link rel="stylesheet" href="../css/Resume.css">
<?php
    if(isset($_POST['ok']))
    {
      $rid=$_POST['getid'];
      $sql="SELECT * FROM resume where RID='$rid' ";

      $result=$conn -> query($sql);

      if($result -> num_rows>0)
      {
          while($row=$result->fetch_assoc())
          {
            $rid=$_POST["getid"];
            $name=$row["Name"];
            $address=$row["Address"];
            $age=$row["Age"];
            $dob=$row["DOB"];
            $status=$row["Status"];
            $profile=$row["Profile"];
            $edu=$row["Edu"];
            $exp=$row["Exp"];

          }
      }
      else {
        echo "No record Found";
      }

    }
    else {
      echo "No Record Found";
    }
  ?>


  <form action="Update_resume.php" method="post">
    <div class="form">
      <div class="form1">



        <label for="">RID :- </label>
        <input type="text" name="rid"  value="<?php echo $rid ?>" readonly>

  <br><br>  <label for="">Full Name :-</label>
    <input type="text" name="name" value=<?php echo $name?>><br><br>

    <label for="">Address :-</label>  &nbsp &nbsp
    <input type="text" name="address" value=<?php echo $address?>><br><br>

    <label for="">Age :-</label>  &nbsp &nbsp  &nbsp &nbsp
      <input type="text" name="age" value=<?php echo $age?>><br><br>

    <label for="">Date Of Birth :</label>
  <input type="text" name="dob" value=<?php echo $dob?>><br><br>

    <label for="">Civil Status :-</label>
    <input type="text" name="status" value=<?php echo $status?>><br><br>



              <div class="form2">
                <h2>Profile</h2><br>
                <input type="textarea" id="textarea" name="Profile" value=<?php echo $profile?>><br><br>

                <h2>Education</h2><br>

                <input type="textarea" id="textarea" name="education" value=<?php echo  $edu?>><br><br>

                <h2>Experiance</h2><br>
                <input type="textarea" id="textarea" name="experiance" value=<?php echo $exp?>><br><br>

                <button class="Edit" type="submit" name="button" action="Update_resume.php">Update</button>

              <?php
                  echo "<a href= 'Delete_Resume.php?id=".$rid."'>Delete</a>";
               ?>

    </div>
      </div>
    </div>



      </form>
