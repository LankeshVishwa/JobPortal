<?php
    include_once 'config.php';
?>

<?php
	$rid = $_GET['id'];

	$sql = "DELETE FROM resume WHERE RID = '$rid'";

	if($conn -> query($sql)){
		echo "<script> alert('Records deleted successfully!!!!')</script>";
		header("Location:Resume.php");
	}
	else{
		echo "ERROR INSERTING :- ".$conn->error;
	}

	//Close connection
	mysqli_close($conn);

?>
