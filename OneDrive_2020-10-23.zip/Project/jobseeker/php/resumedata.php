<?php
  include_once 'config.php';
 ?>
<?php
  $rid=$_POST["RID"];
  $name=$_POST["Name"];
  $address=$_POST["Address"];
  $age=$_POST["Age"];
  $dob=$_POST["DOB"];
  $status=$_POST["status"];
  $profile=$_POST["Profile"];
  $edu=$_POST["Edu"];
  $exp=$_POST["Exp"];

  $sql="insert into resume(RID,Name,Address,Age,DOB,Status,Profile,Edu,Exp)values('','$name','$address','$age','$dob','$status','$profile','$edu','$exp')";

  if(mysqli_query($conn,$sql))
  {
    echo "<script>alert ('Data Input Successfully !!!')</script>";
    header("Location:Resume.php");
  }
  else {
    echo "<script>alert ('Error in Insertinh records')</script>";
  }
  mysqli_close($conn);
  ?>
