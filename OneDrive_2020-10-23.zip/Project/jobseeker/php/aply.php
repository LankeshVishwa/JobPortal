<!DOCTYPE html>
<html>
  <head>
    <title></title>
      <link rel="stylesheet" href="../css/Resume.css">
  </head>
  <body>
<?php

include 'config.php';



$rid=$_REQUEST['id'];
$sql="SELECT * FROM employerpost where Employer_ID='$rid' ";

$result=$conn -> query($sql);

if($result -> num_rows>0)
{
    while($row = $result->fetch_assoc())
    {


      $cat=$row['Job_Category'];
      $id=$row["Employer_ID"];
      $name=$row["Company_Name"];
      $email=$row["Company_Email"];

}
}
 ?>


<center>
    <form action="add.php" method="POST" >
   		<label>Job Title</label>
   		<input type="text" name="title" value= <?php echo $cat ?> readonly/><br><br><br><br>

   		<label>Employer ID</label>
   		<input type="text" name="emp_id" value= <?php echo $id ?> readonly/> <br><br><br><br>

   		<label>Company Name</label>
   		<input type="text" name="name" value= <?php echo $name?> readonly/><br><br><br><br>

   		<label>Company Email</label>
   		<input type="text" name="email"  value= <?php echo $email ?> readonly/><br><br><br><br>

      <label>Resume ID</label>
      <input type="text" name="RID"  value= "" /><br>

   		<input type="Submit" value="Update" >
</center>
   	</form>

   </body>
 </html>
