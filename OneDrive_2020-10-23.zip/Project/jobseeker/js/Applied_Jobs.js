function Job()
{
    var text;
    if(confirm("Do you want to delete this application ?"))
    {
      txt="You pressed ok !";
    }
    else{
      txt="You pressed cancel";
    }
    document.getElementById("demo").innerHTML=text;
}
