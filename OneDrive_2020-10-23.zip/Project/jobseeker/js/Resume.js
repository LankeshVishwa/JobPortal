
function myFunction() {

  var checkBox = document.getElementById("Check");

  var submit = document.getElementById("submit");

  if (checkBox.checked == true)
  {
    submit.style.display = "block";
  }
  else
  {
     submit.style.display = "none";
  }
}

function myFunction1()
{
    var txt;
    if(confirm("Do you want to Logout ?"))
    {
      txt="You pressed ok !";
    }
    else{
      txt="You pressed cancel";
    }
    document.getElementById("demo").innerHTML=txt;
}
