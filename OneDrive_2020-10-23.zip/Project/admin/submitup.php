<?php

	require 'config.php';
	
$id=$_POST["Emp_id"];	
$name = $_POST['Fullname'];
$email=$_POST['Email'];
$address=$_POST['Address'];
$Ntype=$_POST['Type'];




$sql=" UPDATE employee SET Fullname = '$name' , Email = '$email' , Address = '$address' , Type = '$Ntype'  where  Emp_id = '$id' ";
			
	
	
 
		if(mysqli_query($con,$sql))
		{
			echo "<script>alert('Record updated successfully')</script>";
			header("location:assist.php");
		}
		else
		{
			echo "<script>alert('Error: could not updated')</script>";
		}
		mysqli_close($con);
	
?>	
	
	
	
	
	
	
	