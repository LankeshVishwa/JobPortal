<?php

require 'config.php'

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="styles/manage.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <meta charset="utf-8">
    <title>Manage Accounts</title>
  </head>
  <body>
<div class="polygon">
      <div class="logo">
        <img class="img" src="images/logo.png" alt="logo image">
      </div>

      <header>
        <ul class="nav">
          <li><a href="adminhome.html">Home</a></li>
          <li><a href="report.php">Statistics</a></li>
          <li><a href="manage.php">Manage Accounts</a></li>
          <li><a href="assist.php">Manage System Assistant</a></li>
        </ul>
      </header>

      <br><br><br><br><br><br><br><br><br><br><br><br>
<center>
<h1>Accounts Details</h1>
<br><br><br>
<p>
  
</p>
<h2>Manage Employers</h2>
<br><br>
<!--Table_1-->

  <table  class="content-table" >
  <thead>
				<tr>
					<th>Employer ID</th>
					<th>Employer Name </th>
					<th>Email </th>
					<th style="background-color:#FF0000">Delete </th>
				
				
				</tr>
				
				</thead>
			<!-- GET DATA FROM ITEM TABLE-->	
			<?php
				$sql="SELECT * FROM empadmin ";
				
				$result=$con ->query($sql);
				
				if($result -> num_rows > 0)
				{
					while($row = $result -> fetch_assoc())
					{ 
						$id=$row["Employer_ID"];
						$name=$row["Full_name"];
						$email=$row["Email"];
						
						
						
						
						echo"<tr> 
								
								 <td >".$row["Employer_ID"]."</td>
								<td>".$row["Full_name"]."</td>
								 <td>".$row["Email"]."</td>
								<td> <button type='submit' id = 'delete'><a href='deleteEMP.php?id=$id'>delete</a></button></td>

							 </tr>";
					}
				}
				else
				{
					echo "no result";
				}	
			echo"</table>";
			?>
 
     <br><br><br><br><br><br><br><br><br><br><br><br>
</p>
<h2>Manage Job Seekers</h2>
<br><br>
<!--Table_2-->

<table class="content-table">
  <thead>
    <tr>
      <th>Jobseeker ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email</th>
      <th>Location</th>
      <th>Resume ID</th>
      <th style="background-color:#FF0000">Delete</th>

    </tr>
  </thead>
<!-- GET DATA FROM ITEM TABLE-->	
			<?php
				$sql="SELECT * FROM seekeradmin ";
				
				$result=$con ->query($sql);
				
				if($result -> num_rows > 0)
				{
					while($row = $result -> fetch_assoc())
					{ 
						$id=$row["JS_ID"];
						$fname=$row["JS_FName"];
						$lname=$row["JS_LName"];
						$email=$row["Email"];
						$location=$row["Location"];
						$rid=$row["resume_id"];
						
						
						echo"<tr> 
								
								<td>".$row["JS_ID"]."</td>
								<td>".$row["JS_FName"]."</td>
								<td>".$row["JS_LName"]."</td>
								<td>".$row["Email"]."</td>
								<td>".$row["Location"]."</td>
								<td>".$row["resume_id"]."</td>

								<td> <button type='submit' id = 'delete'><a href='deletejs.php?id=$id'>delete</a></button></td>

							 </tr>";
					}
				}
				else
				{
					echo "no result";
				}	
			echo"</table>";
			?>
 
     <br><br><br><br>
</table>
      
</center>





<hr>
<footer>
    <div class="main-content">
        <div class="center box">
            <h2>Address</h2>

                <div class="content">
                      <div class="place">
                        
                          <span class="fas fa-map-marker-alt"></span>
                          <span class="text">306,peradeniya,kandy</span>



                          <span class="fas fa-phone-alt"></span>
                          <span class="text">+94 770 740 370</span>



                          <span class="fas fa-envelope"></span>
                          <span class="text">abc@example.com</span>

                        </div>
                </div>
        </div>

      <div class="right box">
          <h2>Contact us</h2>
              <div class="content">
                    <form action="#">
                          <div class="email">
                                <div class="text">Email *</div>
                                <input type="email" required>
                          </div>

                          <div class="msg">
                                  <div class="text">Message*</div>
                                  <textarea id=".msgForm" rows="2" cols="25" required></textarea>

  <br/>
                        <div class="btn">
                          <button type="submit">Send</button>
                        </div>
                        </div>
              </div>
        </div>
      </div>
    </div>
</footer>
  </body>
</html>
