<?php

	require 'config.php';
	
	$recordId=$_GET['id'];

global $id;
global $fname;
global $lname;
global $email;
global $location;
global $rid;



				$sql="SELECT * FROM seekeradmin where JS_ID =  '$recordId'";
				
				$result=$con ->query($sql);
				
				if($result -> num_rows > 0)
				{
					while($row = $result -> fetch_assoc())
					{ 

					$id=$row["JS_ID"];
					$fname=$row["JS_FName"];
					$lname=$row["JS_LName"];
					$email=$row["Email"];
					$location=$row["Location"];
					$rid=$row["resume_id"];
					



					}
					
				}



$sql2="INSERT INTO jobseeker_delete(JS_ID,JS_FName,JS_LName,Email,Location,resume_id) 
	 VALUES('$id','$fname','$lname','$email','$location','$rid')";
	 
	if($con->query($sql2))
	{
		//echo'<script>alert("Record inserted successfully")</script>';
	    //location="manage.php";
	
	}
	else
	{
		echo"<script>alert('Error')</script>";
	}
	
	//$con->close();
	 
	 


	$sql="DELETE FROM seekeradmin  where  JS_ID = '$id' ";		
	
	
	


		if(mysqli_query($con,$sql))
		{
			echo "<script>alert('Record Deleted successfully');
			window.location='manage.php';
			
			</script>";
			
		}
		else
		{
			echo "<script>alert('Error: could not deleted')</script>";
		}
		mysqli_close($con);
	
?>	
	
	
	
	
	
	
	