<?php

$con = new mysqli("localhost","root","","online_job_portal");

if($con ->connect_error)
{
	die("error".$con ->connect_error);
	
}

else
{
	echo "success";
	echo "<br/>";
}

?>