-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2020 at 01:33 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `empadmin`
--

CREATE TABLE `empadmin` (
  `Employer_ID` char(10) NOT NULL,
  `Full_name` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `empadmin`
--

INSERT INTO `empadmin` (`Employer_ID`, `Full_name`, `Email`) VALUES
('E10983', 'John Cooper', 'john@abc.com'),
('E12345', 'Nolan correy', 'nolan@abc.com'),
('E23456', 'Liam Lois', 'liam@abc.com'),
('E45127', 'Keith Smith', 'ksmith@abc.com'),
('E45699', 'Sama Kasti', 'Sama@abc.com'),
('E60023', 'Don Bradman', 'don@abc.com'),
('E78938', 'Will Pitt', 'will@abc.com');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Emp_id` int(11) NOT NULL,
  `Fullname` varchar(100) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Emp_id`, `Fullname`, `Email`, `Address`, `Type`) VALUES
(1, 'Robin Fernando', 'RobinF@gmail.com', 'No.77, Colombo street, Kandy', 'Administrator'),
(2, 'Ruchira Ranasinghe', 'RuchiraR@gmail.com', 'No.99, Primrose road, Kandy', 'Administrator'),
(3, 'Sampath Samarakoon', 'SampathS@gmail.com', 'No38., Park road, Kandy', 'System Assistant'),
(4, 'Dilshan perera', 'DilshanP@gmail.com', 'No.10, Flower street, Kandy', 'System Assistant'),
(5, 'Kamal Herath', 'RobinF@gmail.com', 'No.07, Christoper road, Kandy', 'System Assistant');

-- --------------------------------------------------------

--
-- Table structure for table `employer_delete`
--

CREATE TABLE `employer_delete` (
  `Employer_ID` char(10) NOT NULL,
  `Full_name` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employer_delete`
--

INSERT INTO `employer_delete` (`Employer_ID`, `Full_name`, `Email`) VALUES
('', '', ''),
('E78938', 'Will Pitt', 'will@abc.com'),
('E90876', 'Sam Pool', 'sam@abc.com');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker_delete`
--

CREATE TABLE `jobseeker_delete` (
  `JS_ID` char(6) DEFAULT NULL,
  `JS_FName` varchar(50) DEFAULT NULL,
  `JS_LName` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Location` varchar(15) DEFAULT NULL,
  `resume_id` char(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobseeker_delete`
--

INSERT INTO `jobseeker_delete` (`JS_ID`, `JS_FName`, `JS_LName`, `Email`, `Location`, `resume_id`) VALUES
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007');

-- --------------------------------------------------------

--
-- Table structure for table `seekeradmin`
--

CREATE TABLE `seekeradmin` (
  `JS_ID` char(6) DEFAULT NULL,
  `JS_FName` varchar(50) DEFAULT NULL,
  `JS_LName` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Location` varchar(15) DEFAULT NULL,
  `resume_id` char(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seekeradmin`
--

INSERT INTO `seekeradmin` (`JS_ID`, `JS_FName`, `JS_LName`, `Email`, `Location`, `resume_id`) VALUES
('10033', 'Wade', 'Wilson', 'wmaxwell@gmail.com', 'Moscow', '1003'),
('10055', 'Frank', 'Patinson', 'fpatinson@gmail.com', 'Adelaid', '1007'),
('10077', 'Ruby', 'Lousy', 'Rubyl@gmail.com', 'Brisbane', '1009'),
('10099', 'John', 'Little', 'littjo@gmail,com', 'Canberaa', NULL),
('10111', 'Smith', 'Marcus', 'smithmarc@gmail.com', 'Gaza', NULL),
('10012', 'Jonas', 'Marker', 'jomarker@gmail.com', 'New york', '1001'),
('10133', 'Warner', 'Williamson', 'williamson@gmial.com', 'Kingston', '1007');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empadmin`
--
ALTER TABLE `empadmin`
  ADD PRIMARY KEY (`Employer_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Emp_id`);

--
-- Indexes for table `employer_delete`
--
ALTER TABLE `employer_delete`
  ADD PRIMARY KEY (`Employer_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
