1. Download the zip file.

5. Extract the file and copy "JP" folder

6. Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name = job portal

6. Import admin.sql file (if you want read the admin.sql text file)

7. Run the script http://localhost/JP

8. Watch the video to get an idea about functioning of admin webpages.
