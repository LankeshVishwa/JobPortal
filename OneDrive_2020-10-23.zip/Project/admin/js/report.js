var progressBarOptions = {
	startAngle: -1.55,
	size: 180,
    value: 0.85,
    fill: {
		color: '#66309c'
	}
}

$('.circle').circleProgress(progressBarOptions).on('circle-animation-progress', function(event, progress, stepValue) {
	//$(this).find('strong').text(String(stepValue.toFixed(2)).substr(1));
});

$('.linebar').LineProgressbar({
  percentage: 85,
  fillBackgroundColor: '#66309c',
  height: '15px',
  radius: '15px',
	ShowProgressCount: false
});
