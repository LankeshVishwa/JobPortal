<?php

require 'config.php';


$id = $_POST['Emp_id'];
$name=$_POST['Fullname'];
$email=$_POST['Email'];
$address=$_POST['Address'];
$type=$_POST['Type'];






$sql="INSERT INTO employee(Emp_id,Fullname,Email,Address,Type) 
	 VALUES('$id','$name','$email','$address','$type')";
	
	if($con->query($sql))
		//if(mysqli_query ($con,$sql)) 
	{
		echo"<script>alert('Record inserted successfully')</script>";
	    header("location:assist.php");
	
	}
	else
	{
		echo"<script>alert('Error')</script>";
	}
	
	$con->close();
	?>
		