<?php

	require 'config.php';
	
	$recordId=$_GET['id'];

global $id;
global $name;
global $email;


				$sql="SELECT * FROM empadmin where Employer_ID =  '$recordId'";
				
				$result=$con ->query($sql);
				
				if($result -> num_rows > 0)
				{
					while($row = $result -> fetch_assoc())
					{ 

					$id=$row["Employer_ID"];
					$name=$row["Full_name"];
					$email=$row["Email"];
					



					}
					
				}



$sql2="INSERT INTO employer_delete(Employer_ID,Full_name,Email) 
	 VALUES('$id','$name','$email')";
	 
	if($con->query($sql2))
	{
		//echo'<script>alert("Record inserted successfully")</script>';
	    //location="manage.php";
	
	}
	else
	{
		//echo"<script>alert('Error')</script>";
	}
	
	//$con->close();
	 
	 


	$sql="DELETE FROM empadmin  where  Employer_ID = '$id' ";		
	
	
	


		if(mysqli_query($con,$sql))
		{
			echo "<script>alert('Record Deleted successfully');
			window.location='manage.php';
			
			</script>";
			
		}
		else
		{
			echo "<script>alert('Error: could not deleted')</script>";
		}
		mysqli_close($con);
	
?>	
	
	
	
	
	
	
	