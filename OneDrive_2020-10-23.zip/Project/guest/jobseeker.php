<?php

	include 'config.php';

	$FirstName = $_POST['fname'];
	$LastName = $_POST['lname'];
	$Gender = $_POST['gender'];
	$MobileNumber =$_POST['mobile'];
	$Email = $_POST['email'];
	$Password = $_POST['pwd'];
	$Country = $_POST['country'];
	$DateofBirth = $_POST['dob'];
	$PositionInformation = $_POST['posi'];
	$JobExperience = $_POST['exp'];
	$CompanyName = $_POST['cname'];
	$Designation = $_POST['designation'];
	$Salary = $_POST['salary'];


	$sql="INSERT INTO js(fname,lname,gender,mobile,email,pwd,country,dob,posi,exp,cname,designation,salary)
		  VALUES ('$FirstName','$LastName','$Gender','$MobileNumber','$Email','$Password','$Country',
				'$DateofBirth','$PositionInformation','$JobExperience','$CompanyName','$Designation','$Salary')";
				
	if($con-> query($sql))
	{
		echo "You have Succcesfully Registered";
		header("Location:seeker.html");
	}
	else{
		echo"Error inserting".$con->error;
	}
	$con -> close();
	
	
	
?>