<?php

	include 'config.php';
	
	if(isset($_POST['email'])){
		
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		$sql = "select * from js where email='".$email."'AND pwd='".$password."'
		limit 1";
		
		$result=$con->query($sql);
		
		if($result->num_rows==1){
			echo "Login suceesfull";
			header("Location:../jobseeker/php/Job_apply.php");
			
			exit();
			
		}
		else{
			echo "  Forgot Password  OR  Create an ACCOUNT";
			exit();
		}
	}
		
	
	
	
?>
	
	

