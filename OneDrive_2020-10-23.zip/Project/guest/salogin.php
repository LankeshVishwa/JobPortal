<?php

	include 'config.php';
	
	if(isset($_POST['email'])){
		
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		$sql = "select * from employee where Email='".$email."'AND Type='".$password."'
		limit 1";
		
		$result=$con->query($sql);
		
		if($result->num_rows==1){
			echo "Login suceesfull";
			header("Location:../SA/html/index.html");
			
			exit();
			
		}
		else{
			echo "  Forgot Password  OR  Create an ACCOUNT";
			exit();
		}
	}
		
	
	
	
?>