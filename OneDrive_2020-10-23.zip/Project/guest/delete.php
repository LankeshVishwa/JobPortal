<?php

	include 'config.php';
	
	if(isset($_POST['delete']))
	
	$email= $_POST['email'];
	
	
	
	$query = "DELETE FROM  `js` WHERE `email` = '".$email."' limit 1";
	
	$result = mysqli_query($con, $query);
	
	
	if($result)
	{
		echo 'Account Deleted';
	}
	else
	{
		echo 'Account Not Deleted';
	}
	mysqli_close($con);
	
	
	
	
	
	
	
	
	
?>
	

