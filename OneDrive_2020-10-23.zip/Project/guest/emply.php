<?php

	include 'config.php';

	$Name = $_POST['fname'];
	$Gender = $_POST['gender'];
	$Mobile_Number = $_POST['mobile'];
	$Email_Address = $_POST['email'];
	$DateofBirth = $_POST['dob'];
	$Password = $_POST['pwd'];
	$Companyname = $_POST['cname'];
	$Bussiness_ctgry = $_POST['bsctgry'];
	$Position = $_POST['position'];
	$CompanyAddress = $_POST['caddress'];
	
	


	$sql="INSERT INTO emp(Name,Gender,Mobile_number,Email,Date_of_birthday,Password,Company_name,Business_catgry,Position,Company_address)
		  VALUES ('$Name','$Gender','$Mobile_Number','$Email_Address','$DateofBirth','$Password',
				'$Companyname','$Bussiness_ctgry','$Position','$CompanyAddress')";
				
	if($con-> query($sql))
	{
		echo "You have Succcesfully Registered";
		header("Location:emplog.html");
	}
	else{
		echo"Error inserting".$con->error;
	}
	$con -> close();
	
	
	
?>