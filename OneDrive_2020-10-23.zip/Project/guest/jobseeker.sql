-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2020 at 06:26 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobseeker`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Email` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Phone number` int(10) NOT NULL,
  `contact ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `ID` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Gender` varchar(1) NOT NULL,
  `Mobile_number` int(11) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Date_of_birthday` int(11) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Company_name` varchar(20) NOT NULL,
  `Business_catgry` varchar(20) NOT NULL,
  `Position` varchar(20) NOT NULL,
  `Company_address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`ID`, `Name`, `Gender`, `Mobile_number`, `Email`, `Date_of_birthday`, `Password`, `Company_name`, `Business_catgry`, `Position`, `Company_address`) VALUES
(9, 'don Bradman', 'M', 751236500, 'don@abc.com', 1990, 'don90', 'Apache', 'Insurance', 'Dellhi', 'Main rd,Dellhi'),
(11, 'Sama kasti', 'F', 723014789, 'sama@gmail.com', 1996, 'samak96', 'Black berry', 'Web services', 'london', 'Red rd, london'),
(12, 'Liam Lois', 'M', 786549200, 'liam@gmail.com', 1994, 'liam942', 'BSA', 'Advertising', 'HongKong', 'Lanne rd, hong kong'),
(13, 'Sam Pool ', 'M', 763004780, 'sam@abcgmail.com', 1996, 'sampool', 'cannon', 'Accounting', 'bangalore', 'New bangalore'),
(14, 'Nolan correy', 'M', 720236598, 'nolan@abc.com', 1987, 'nolan87', 'cisco', 'insurance', 'kingston', 'king rd, kingston'),
(15, 'keith smith', 'M', 705698784, 'smith@gmail.com', 1993, 'smithk123', 'COLT', 'Banking', 'Madrid', 'Main street, Madrid'),
(16, 'Will pitt', 'M', 701236459, 'will@abc.com', 1996, 'will96pitt', 'CRC Press', 'Legal service', 'Monaco', 'cherry lane, monaco'),
(20, 'John Cooper', 'M', 702365801, 'john@abc.com', 1991, 'john1230', 'Dell', 'Marketing', 'colombo', 'Market rd, colombo');

-- --------------------------------------------------------

--
-- Table structure for table `js`
--

CREATE TABLE `js` (
  `ID` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `mobile` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `dob` int(11) NOT NULL,
  `posi` varchar(10) NOT NULL,
  `exp` varchar(10) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `salary` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `js`
--

INSERT INTO `js` (`ID`, `fname`, `lname`, `gender`, `mobile`, `email`, `pwd`, `country`, `dob`, `posi`, `exp`, `cname`, `designation`, `salary`) VALUES
(13, 'Ruby', 'Lousy', 'M', 711237503, 'rubyl@gmail.com', 'rusy96', 'Brisbane', 1996, 'full_time', 'Previous_j', 'orian solution', 'Manager', '5000000'),
(14, 'John', 'Little', 'M', 763984780, 'littjo@gmail.com', 'jon90', 'Canbera', 1990, 'full_time', 'fresher', 'Golden software', 'Technician', '50000'),
(17, 'Warner', 'Williamson', 'M', 715823650, 'williamson@gmail.com', 'willi91', 'Gaza', 1991, 'part_time', 'fresher', 'ARP', 'computer Processor', '75000'),
(18, 'Smith', 'Marcus', 'M', 750236500, 'smithmarc@gmail.com', 'smith123', 'Gaza', 1991, 'part_time', 'Previous_j', 'AOL', 'computer engineer', '65000'),
(23, 'Jonas', 'Marker', 'M', 711299500, 'jomarker@gmail.com', 'jomark', 'london', 1993, 'full_time', 'Previous_j', 'Orion solution', 'designer', '2000000'),
(24, 'wade', 'wilson', 'M', 701299550, 'wmaxwell@gmail.com', 'max123', 'Moscow', 1991, 'part_time', 'fresher', 'Data Marker', 'engineer', '3000000'),
(25, 'frank', 'Patinson', 'M', 765579550, 'fpatinson@gmail.com', 'patin90', 'Adelade', 1987, 'weeekend', 'current_jo', 'HDS', 'Developer', '200000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact ID`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `js`
--
ALTER TABLE `js`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emp`
--
ALTER TABLE `emp`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `js`
--
ALTER TABLE `js`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
