<?php

	include 'config.php';
	
	if(isset($_POST['email'])){
		
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		$sql = "select * from emp where Email='".$email."'AND Password='".$password."'
		limit 1";
		
		$result=$con->query($sql);
		
		if($result->num_rows==1){
			echo "Login suceesfull";
			header("Location:../employer/index.html");
			
			exit();
			
		}
		else{
			echo "You have Entered incorrect login details !!!! 
			Please Forgot Password...";
			exit();
		}
	}
		
	
	
	
?>
	
	

