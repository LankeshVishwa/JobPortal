<?php

$Servername = "localhost";
$Username = "root";
$Password = "";
$Database = "online_job_portal";

$con = new mysqli($Servername, $Username,$Password,$Database );

if($con->connect_error)
{
	die("Mistake" .$con->connect_error);
	
}
echo "Successfully Connected......";



?>
